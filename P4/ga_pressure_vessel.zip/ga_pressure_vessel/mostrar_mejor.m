function mostrar_mejor(x)

coste = 0.6224*x(1)*x(3)*x(4) + 1.7781*x(2)*x(3)^2 + 3.1661*x(1)^2*x(4) + 19.86*x(1)^2*x(3);
volumen = pi*x(3)^2*x(4) + (4/3)*pi*x(3)^3;

fprintf('\nThe best solution was found in (Ts Th R L) = (%.4f,%.4f,%.4f,%.4f)',...
    x(1),x(2),x(3),x(4));
fprintf('\nThe total cost of the vessel is %f',coste);
fprintf('\nThe volume of the vessel is %f',volumen);
fprintf('\nThe ratio Ts/R is %f', x(1)/x(3));
fprintf('\nThe ratio Th/R is %f\n\n', x(2)/x(3));

end