%FUNCION CALCULA LOS VALORES DE LAS FUNCIONES OBJETIVO
function [fval, pop]=fitness_function(nvars, nindg, pop)

fval = zeros(nindg,1);
for ni = 1:nindg
    %Reparamos la solución
    for nj = 1:2
        c = round(pop(ni,nj)/0.0625);
        pop(ni,nj) = 0.0625*c;
    end

    for i=3:4
        pop(ni,nj) = round(pop(ni,nj),6);
    end

    x = zeros(1,nvars);
    for nj = 1:nvars
        x(nj) = pop(ni,nj);
    end    
    
    %Función objetivo: coste de construir la vasija
    fval(ni,1) = 0.6224*x(1)*x(3)*x(4) + 1.7781*x(2)*x(3)^2 + ...
        3.1661*x(1)^2*x(4) + 19.86*x(1)^2*x(3);
    
    % Volumen de la vasija: ha de tener un volumen mínimo de 750 ft^3
    volumen = pi*x(3)^2*x(4) + (4/3)*pi*x(3)^3;
    if volumen-750*12^3<0
        fval(ni,1) = fval(ni,1) + 1.e20*(volumen-750*12^3)^2;
    end

    %Como el tanque de almacenamiento de aire debe soportar una presión de trabajo
    %de 2000 psi , se han de verificar las siguientes relaciones entre el radio
    %interno del cilindro y el ancho de las paredes de la estructura y de la cabeza, 
    %respectivamente 
    if x(1)-0.0193*x(3)<0
        fval(ni,1) = fval(ni,1) + 1.e20*(x(1)-0.0193*x(3))^2;
    end
    if x(2)-0.00954*x(3)<0
        fval(ni,1) = fval(ni,1) + 1.e20*(x(2)-0.00954*x(3))^2;
    end
end

end